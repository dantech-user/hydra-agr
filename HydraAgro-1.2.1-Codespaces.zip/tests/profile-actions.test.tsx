import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { ProfileScreen } from "../src/features/profile/profile-screen";
import { createEmptyAccount, type UpdateAccount } from "../src/lib/hydra-types";

function setup() {
  const account = createEmptyAccount({ id: "profile-user", email: "produtor@hydra.test" });
  account.profile.name = "Produtor Teste";
  account.property.name = "Fazenda Teste";
  const updateAccount = vi.fn(async () => undefined) as UpdateAccount;
  const navigate = vi.fn();
  const logout = vi.fn(async () => undefined);

  render(<ProfileScreen
    account={account}
    links={[]}
    updateAccount={updateAccount}
    navigate={navigate}
    logout={logout}
    saveAvatar={async () => false}
    savePropertyCover={async () => false}
    changeCredentials={async () => ({ ok: true, message: "Atualizado" })}
  />);

  return { updateAccount, logout };
}

describe("ações de preferências e segurança", () => {
  it.each([
    ["Segurança", "E-mail e senha"],
    ["Apoie o Hydra Agro", "Apoie o Hydra Agro"],
    ["Termos de uso", "Termos de uso"],
    ["Política de privacidade", "Política de privacidade"],
    ["Sobre o Hydra Agro", "Sobre o Hydra Agro"],
  ])("abre %s no modal correto", (buttonName, dialogName) => {
    setup();
    fireEvent.click(screen.getByRole("button", { name: new RegExp(`^${buttonName}`) }));
    expect(screen.getByRole("dialog", { name: dialogName })).toBeInTheDocument();
  });

  it("altera a preferência de notificações", () => {
    const { updateAccount } = setup();
    fireEvent.click(screen.getByRole("switch", { name: "Notificações" }));
    expect(updateAccount).toHaveBeenCalledTimes(1);
  });

  it("abre a confirmação e conclui a saída da conta", async () => {
    const { logout } = setup();
    fireEvent.click(screen.getByRole("button", { name: "Sair desta conta" }));
    expect(screen.getByRole("dialog", { name: "Sair desta conta?" })).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Confirmar saída" }));
    await waitFor(() => expect(logout).toHaveBeenCalledTimes(1));
  });
});
