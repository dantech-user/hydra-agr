"use client";

import { useMemo, useState } from "react";
import {
  Bell,
  BellRing,
  CheckCheck,
  ChevronRight,
  Crown,
  Droplets,
  LoaderCircle,
  Megaphone,
  RefreshCw,
  Sprout,
} from "lucide-react";
import { showAppToast } from "../../components/modal-system";
import { EmptyState, LoadingButton, Modal, ScreenHeader, Toggle } from "../../components/ui";
import type { AppNotification, AuthResult, HydraAccount, UpdateAccount } from "../../lib/hydra-types";

type Props = {
  account: HydraAccount;
  updateAccount: UpdateAccount;
  onBack: () => void;
  setNotificationRead: (notification: AppNotification, read: boolean) => Promise<AuthResult>;
  markAllNotificationsRead: () => Promise<AuthResult>;
  refreshNotifications: () => Promise<AuthResult>;
};

type PreferenceDraft = Pick<HydraAccount["settings"], "pushNotifications" | "propertyAlerts" | "adminNotices" | "waterAlerts">;

function preferencesFrom(account: HydraAccount): PreferenceDraft {
  return {
    pushNotifications: account.settings.pushNotifications,
    propertyAlerts: account.settings.propertyAlerts,
    adminNotices: account.settings.adminNotices,
    waterAlerts: account.settings.waterAlerts,
  };
}

function noticeLabel(item: AppNotification) {
  if (item.kind === "subscription") return "Hydra Agro+";
  if (item.kind === "water") return "Água";
  if (item.kind === "property") return "Propriedade";
  if (item.kind === "admin" || item.source === "announcement") return "Administração";
  return "Comunicado";
}

function NoticeIcon({ item }: { item: AppNotification }) {
  if (item.kind === "subscription") return <Crown size={21} />;
  if (item.kind === "water") return <Droplets size={21} />;
  if (item.kind === "property") return <Sprout size={21} />;
  if (item.kind === "admin" || item.source === "announcement") return <Megaphone size={21} />;
  return <BellRing size={21} />;
}

function formatNoticeDate(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "Data não informada";
  return date.toLocaleString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function NotificationsScreen({
  account,
  updateAccount,
  onBack,
  setNotificationRead,
  markAllNotificationsRead,
  refreshNotifications,
}: Props) {
  const [preferences, setPreferences] = useState<PreferenceDraft>(() => preferencesFrom(account));
  const [filter, setFilter] = useState<"all" | "unread">("all");
  const [selected, setSelected] = useState<AppNotification | null>(null);
  const [busy, setBusy] = useState<"preferences" | "all" | "refresh" | "notice" | null>(null);
  const [error, setError] = useState("");
  const unread = account.notifications.filter((item) => !item.read).length;
  const visible = useMemo(
    () => account.notifications.filter((item) => filter === "all" || !item.read),
    [account.notifications, filter],
  );

  async function savePreferences() {
    setBusy("preferences");
    setError("");
    try {
      await updateAccount((current) => ({
        ...current,
        settings: { ...current.settings, ...preferences },
      }), { requireRemote: true });
      showAppToast("Alterações salvas com sucesso.");
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Não foi possível salvar as preferências.");
    } finally {
      setBusy(null);
    }
  }

  async function refresh() {
    setBusy("refresh");
    setError("");
    const result = await refreshNotifications();
    setBusy(null);
    if (result.ok) showAppToast(result.message, "info");
    else setError(result.message);
  }

  async function markAll() {
    setBusy("all");
    setError("");
    const result = await markAllNotificationsRead();
    setBusy(null);
    if (result.ok) showAppToast(result.message);
    else setError(result.message);
  }

  async function toggleSelectedRead() {
    if (!selected) return;
    setBusy("notice");
    setError("");
    const nextRead = !selected.read;
    const result = await setNotificationRead(selected, nextRead);
    setBusy(null);
    if (result.ok) {
      setSelected({ ...selected, read: nextRead });
      showAppToast(result.message, "info");
    } else {
      setError(result.message);
    }
  }

  return (
    <div className="screen page-enter extra-screen notifications-screen">
      <ScreenHeader
        eyebrow="PREFERÊNCIAS E AVISOS"
        title="Notificações"
        subtitle="Escolhas persistentes e comunicados reais da sua conta."
        onBack={onBack}
        action={<button className="icon-button" onClick={() => void refresh()} aria-label="Atualizar avisos" disabled={busy === "refresh"}>{busy === "refresh" ? <LoaderCircle size={19} className="spin" /> : <RefreshCw size={19} />}</button>}
      />

      <section className="notification-preference-card">
        <div className="notification-preference-head">
          <span><Bell size={22} /></span>
          <div><small>CONFIGURAÇÕES DA CONTA</small><h2>O que você quer receber</h2><p>As escolhas são salvas no Supabase e permanecem após sair e entrar novamente.</p></div>
        </div>
        <div className="notification-preference-list">
          <div><span><BellRing size={20} /></span><div><strong>Notificações gerais</strong><small>Atividades, monitoramentos e novidades do aplicativo.</small></div><Toggle disabled={busy === "preferences"} checked={preferences.pushNotifications} label="Notificações gerais" onChange={(pushNotifications) => setPreferences({ ...preferences, pushNotifications })} /></div>
          <div><span><Sprout size={20} /></span><div><strong>Alertas da propriedade</strong><small>Situações ligadas aos seus registros rurais.</small></div><Toggle disabled={busy === "preferences"} checked={preferences.propertyAlerts} label="Alertas da propriedade" onChange={(propertyAlerts) => setPreferences({ ...preferences, propertyAlerts })} /></div>
          <div><span><Megaphone size={20} /></span><div><strong>Avisos administrativos</strong><small>Comunicados oficiais e informações importantes.</small></div><Toggle disabled={busy === "preferences"} checked={preferences.adminNotices} label="Avisos administrativos" onChange={(adminNotices) => setPreferences({ ...preferences, adminNotices })} /></div>
          <div><span><Droplets size={20} /></span><div><strong>Alertas de consumo de água</strong><small>Somente quando seus registros permitirem análise real.</small></div><Toggle disabled={busy === "preferences"} checked={preferences.waterAlerts} label="Alertas de consumo de água" onChange={(waterAlerts) => setPreferences({ ...preferences, waterAlerts })} /></div>
        </div>
        {error && <p className="form-error notification-error" role="alert">{error}</p>}
        <LoadingButton className="primary-button full" onClick={() => void savePreferences()} loading={busy === "preferences"} loadingLabel="Salvando alterações...">Salvar preferências</LoadingButton>
      </section>

      <section className="notification-center-section">
        <div className="notification-center-head">
          <div><small>CENTRAL DE AVISOS</small><h2>{unread ? `${unread} não lido${unread === 1 ? "" : "s"}` : "Tudo em dia"}</h2></div>
          {unread > 0 && <LoadingButton className="text-button" onClick={() => void markAll()} loading={busy === "all"} loadingLabel="Marcando..."><CheckCheck size={17} /> Marcar todos</LoadingButton>}
        </div>
        <div className="notification-filter-tabs" role="tablist" aria-label="Filtrar avisos">
          <button className={filter === "all" ? "active" : ""} onClick={() => setFilter("all")} role="tab" aria-selected={filter === "all"}>Todos <span>{account.notifications.length}</span></button>
          <button className={filter === "unread" ? "active" : ""} onClick={() => setFilter("unread")} role="tab" aria-selected={filter === "unread"}>Não lidos <span>{unread}</span></button>
        </div>

        {visible.length === 0 ? (
          <EmptyState
            icon={<Bell size={27} />}
            title={filter === "unread" ? "Nenhum aviso pendente" : "Nenhum aviso recebido"}
            text={filter === "unread" ? "Todos os comunicados desta conta já foram lidos." : "Avisos administrativos, alertas da propriedade e informações do Hydra Agro+ aparecerão aqui."}
          />
        ) : (
          <div className="notification-list rich">
            {visible.map((item) => (
              <button key={`${item.source}-${item.id}`} className={`${item.read ? "is-read" : "is-unread"} ${item.level ?? ""}`} onClick={() => setSelected(item)}>
                <span className="notification-kind-icon"><NoticeIcon item={item} /></span>
                <div>
                  <small>{noticeLabel(item)} · {item.read ? "Lido" : "Não lido"}</small>
                  <strong>{item.title}</strong>
                  <p>{item.body}</p>
                  <time>{formatNoticeDate(item.createdAt)}</time>
                </div>
                <ChevronRight size={18} />
              </button>
            ))}
          </div>
        )}
      </section>

      <Modal open={Boolean(selected)} onClose={() => { setSelected(null); setError(""); }} eyebrow={selected ? noticeLabel(selected).toUpperCase() : "AVISO"} title={selected?.title || "Aviso"} dismissible={busy !== "notice"}>
        {selected && <div className="notification-detail">
          <span className={`notification-detail-icon ${selected.level ?? ""}`}><NoticeIcon item={selected} /></span>
          <p>{selected.body}</p>
          <div className="notification-detail-meta"><span>{selected.read ? "Lido" : "Não lido"}</span><time>{formatNoticeDate(selected.createdAt)}</time></div>
          {error && <p className="form-error" role="alert">{error}</p>}
          <div className="modal-action-row"><button className="secondary-button" onClick={() => setSelected(null)} disabled={busy === "notice"}>Fechar</button><LoadingButton className="primary-button" onClick={() => void toggleSelectedRead()} loading={busy === "notice"} loadingLabel="Atualizando...">{selected.read ? "Marcar como não lido" : "Marcar como lido"}</LoadingButton></div>
        </div>}
      </Modal>
    </div>
  );
}
