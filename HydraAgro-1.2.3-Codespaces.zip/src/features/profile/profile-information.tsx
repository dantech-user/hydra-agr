import { ExternalLink, FileCheck2, Instagram, Mail, ShieldCheck, Sprout } from "lucide-react";

export type ProfileInformationKind = "terms" | "privacy" | "about";

const information = {
  terms: {
    eyebrow: "DOCUMENTO OFICIAL",
    title: "Termos de uso",
    icon: <FileCheck2 size={28} />,
    introduction: "Estes termos explicam como utilizar o Hydra Agro com responsabilidade e quais recursos dependem de serviços ou equipamentos externos.",
    sections: [
      ["1. Finalidade da plataforma", "O Hydra Agro auxilia na organização de dados da propriedade, água, rebanho, atividades, setores, comunidade, NFC/RFID e monitoramento. Ele não substitui orientação veterinária, agronômica, ambiental, jurídica ou de segurança."],
      ["2. Conta e acesso", "O usuário deve fornecer informações verdadeiras, manter e-mail e senha protegidos e avisar o suporte ao identificar uso indevido. Cada pessoa responde pelas ações realizadas em sua conta."],
      ["3. Responsabilidade pelos registros", "Dados de propriedade, animais, água, atividades e monitoramentos são informados pelo próprio usuário. Antes de tomar decisões de manejo, revise os registros e procure o profissional adequado quando necessário."],
      ["4. Gestão rural e água", "Indicadores, metas e tendências são calculados a partir dos registros existentes. A ausência de dados, uma leitura incorreta ou uma conexão indisponível pode limitar os resultados exibidos."],
      ["5. NFC e RFID", "A leitura depende de aparelho Android, permissão e tag compatível. A entrada manual registra somente o código digitado; o Hydra Agro não garante autenticidade física de uma identificação não lida pelo dispositivo."],
      ["6. Monitoramento e Drone Pastor", "Registros manuais de monitoramento estão disponíveis. Integração de voo e telemetria do Drone Pastor é um recurso futuro e somente funcionará com hardware, fornecedor e API compatíveis."],
      ["7. Comunidade", "É proibido publicar conteúdo ilegal, ofensivo, enganoso ou que viole direitos de terceiros. Conteúdos podem ser moderados e contas podem ser restringidas quando houver abuso comprovado."],
      ["8. Hydra Agro+ e apoio", "A assinatura Hydra Agro+ é separada do apoio voluntário. Ativações atuais dependem de confirmação administrativa; o aplicativo não cobra automaticamente nem promete recurso que ainda não esteja integrado."],
      ["9. Recursos experimentais", "Clima, NFC, monitoramento conectado e outras integrações podem depender de terceiros. Recursos em preparação aparecem explicitamente como futuros ou indisponíveis, sem simulação de resultado."],
      ["10. Limitações e disponibilidade", "O serviço pode sofrer interrupções de internet, Supabase, equipamento ou manutenção. O Hydra Agro não garante operação ininterrupta nem resultado produtivo, econômico ou ambiental específico."],
      ["11. Atualizações", "O aplicativo pode receber correções, mudanças de segurança e novos recursos. Alterações relevantes destes termos serão apresentadas com nova data de atualização."],
      ["12. Encerramento de conta", "O usuário pode solicitar exclusão pelos canais oficiais. Sair do aplicativo encerra somente a sessão e não apaga os dados armazenados no servidor."],
    ],
  },
  privacy: {
    eyebrow: "SEUS DADOS",
    title: "Política de privacidade",
    icon: <ShieldCheck size={28} />,
    introduction: "A privacidade foi organizada para que cada conta veja apenas os próprios dados rurais, salvo conteúdos públicos da comunidade e acessos administrativos autorizados pelo servidor.",
    sections: [
      ["Dados da conta", "Podem ser tratados nome, e-mail, telefone, foto, preferências, plano e informações técnicas de autenticação necessárias para manter a sessão segura."],
      ["Dados da propriedade", "Podem ser armazenados nome, município, localização informada, área, tipo, atividades produtivas, fontes de água, setores e metas definidas pelo usuário."],
      ["Animais e identificação", "Fichas de animais, fotos, peso, histórico, observações e códigos NFC/RFID ficam vinculados à conta e à propriedade. O aplicativo não armazena a senha do usuário nas tabelas."],
      ["Água, atividades e monitoramento", "Leituras de água, finalidade, datas, tarefas, ocorrências, fotos e demais registros são usados para histórico, progresso, conquistas e relatórios baseados em dados reais."],
      ["Localização", "O município cadastrado é usado para personalizar a propriedade e consultar o clima. Localização precisa do aparelho somente deve ser acessada quando houver permissão e função que realmente necessite dela."],
      ["Como os dados são utilizados", "As informações permitem autenticação, sincronização, ficha rural, indicadores, alertas, comunidade, suporte, moderação e administração autorizada da plataforma."],
      ["Armazenamento e segurança", "Registros privados são vinculados ao identificador da conta e protegidos pelas políticas de acesso do Supabase. Cargos administrativos são validados no servidor, nunca apenas na interface."],
      ["Clima e serviços externos", "Para consultar o clima, o aplicativo envia somente o nome da cidade e suas coordenadas aproximadas ao serviço meteorológico. E-mail, senha, animais e demais registros rurais não fazem parte dessa consulta."],
      ["Exclusão e direitos", "O titular pode solicitar acesso, correção ou exclusão pelos canais oficiais. Algumas informações poderão ser preservadas quando houver obrigação legal, prevenção de fraude ou necessidade de segurança."],
    ],
  },
  about: {
    eyebrow: "TECNOLOGIA RURAL",
    title: "Sobre o Hydra Agro",
    icon: <Sprout size={28} />,
    introduction: "O Hydra Agro é uma plataforma regional de tecnologia para o agronegócio, criada para aproximar gestão, sustentabilidade e inovação da rotina do produtor.",
    sections: [
      ["O que o aplicativo reúne", "Gestão hídrica, rebanho, identificação NFC/RFID, atividades, setores da propriedade, comunidade, monitoramento e arquitetura preparada para o futuro Drone Pastor."],
      ["Atuação inicial", "O lançamento regional atende Brejões e municípios vizinhos na Bahia. A cidade cadastrada personaliza a propriedade e a consulta meteorológica."],
      ["Compromisso com dados reais", "O aplicativo mostra estados vazios quando não existem registros. Voos, leituras NFC, economia de água e cobranças nunca são inventados."],
      ["Desenvolvimento", "Produto independente em evolução contínua. Recursos que dependem de hardware, API ou pagamento somente são liberados quando a integração correspondente está disponível."],
      ["Próximas etapas", "A integração do Drone Pastor está planejada para uma próxima atualização e dependerá da definição do equipamento e da API oficial. O aviso de evolução não representa voo, telemetria ou conexão já disponível."],
    ],
  },
} as const;

export function ProfileInformation({ kind, onClose, onEmail, onInstagram }: { kind: ProfileInformationKind; onClose: () => void; onEmail: () => void; onInstagram: () => void }) {
  const content = information[kind];
  return (
    <div className="profile-information">
      <header className="legal-intro">
        <span>{content.icon}</span>
        <div><small>{content.eyebrow}</small><p>{content.introduction}</p></div>
      </header>
      <div className="legal-sections">
        {content.sections.map(([title, text]) => <section key={title}><h3>{title}</h3><p>{text}</p></section>)}
      </div>
      <div className="legal-meta"><strong>Hydra Agro · versão 1.2.3</strong><span>Última atualização: 16 de agosto de 2026</span></div>
      <div className="legal-contact-actions">
        <button className="secondary-button" onClick={onEmail}><Mail size={18} /> Suporte</button>
        <button className="secondary-button" onClick={onInstagram}><Instagram size={18} /> Instagram <ExternalLink size={14} /></button>
      </div>
      <button className="primary-button full" onClick={onClose}>Entendi e fechar</button>
    </div>
  );
}
