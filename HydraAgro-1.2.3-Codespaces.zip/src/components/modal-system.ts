"use client";

import { useEffect, useRef, useSyncExternalStore } from "react";

type OverlayEntry = {
  token: symbol;
  requestClose?: () => void;
};

export type AppToast = {
  id: number;
  message: string;
  tone: "success" | "error" | "info";
  closing?: boolean;
};

const overlays: OverlayEntry[] = [];
const overlayListeners = new Set<() => void>();
const toastListeners = new Set<() => void>();
let toasts: AppToast[] = [];
let toastId = 0;
let bodyOverflowBeforeOverlay = "";
let bodyScrollLocked = false;
const emptyToasts: AppToast[] = [];

function emitOverlayChange() {
  const active = overlays.length > 0;
  if (typeof document !== "undefined") {
    document.documentElement.classList.toggle("app-overlay-open", active);
    document.body.classList.toggle("app-overlay-open", active);
    if (active && !bodyScrollLocked) {
      bodyOverflowBeforeOverlay = document.body.style.overflow;
      document.body.style.overflow = "hidden";
      bodyScrollLocked = true;
    } else if (!active && bodyScrollLocked) {
      document.body.style.overflow = bodyOverflowBeforeOverlay;
      bodyScrollLocked = false;
    }
  }
  overlayListeners.forEach((listener) => listener());
}

function registerOverlay(entry: OverlayEntry) {
  overlays.push(entry);
  emitOverlayChange();
  return () => {
    const index = overlays.findIndex((item) => item.token === entry.token);
    if (index >= 0) overlays.splice(index, 1);
    emitOverlayChange();
  };
}

function subscribeOverlay(listener: () => void) {
  overlayListeners.add(listener);
  return () => overlayListeners.delete(listener);
}

function overlaySnapshot() {
  return overlays.length > 0;
}

export function useModalNavigation() {
  return useSyncExternalStore(subscribeOverlay, overlaySnapshot, () => false);
}

export function useAppOverlay(active: boolean, requestClose?: () => void) {
  const token = useRef(Symbol("hydra-overlay"));
  const closeRef = useRef(requestClose);
  closeRef.current = requestClose;

  useEffect(() => {
    if (!active) return;
    return registerOverlay({
      token: token.current,
      requestClose: () => closeRef.current?.(),
    });
  }, [active]);
}

export function requestCloseTopOverlay() {
  overlays.at(-1)?.requestClose?.();
}

function subscribeToasts(listener: () => void) {
  toastListeners.add(listener);
  return () => toastListeners.delete(listener);
}

function toastSnapshot() {
  return toasts;
}

function dismissToast(id: number) {
  const next = toasts.filter((toast) => toast.id !== id);
  if (next.length === toasts.length) return;
  toasts = next;
  toastListeners.forEach((listener) => listener());
}

function closeToast(id: number) {
  if (!toasts.some((toast) => toast.id === id && !toast.closing)) return;
  toasts = toasts.map((toast) => toast.id === id ? { ...toast, closing: true } : toast);
  toastListeners.forEach((listener) => listener());
  window.setTimeout(() => dismissToast(id), 220);
}

export function showAppToast(message: string, tone: AppToast["tone"] = "success") {
  const toast = { id: ++toastId, message, tone } satisfies AppToast;
  toasts = [...toasts, toast].slice(-3);
  toastListeners.forEach((listener) => listener());
  window.setTimeout(() => closeToast(toast.id), tone === "error" ? 4300 : 2800);
  return toast.id;
}

export function useAppToasts() {
  return useSyncExternalStore(subscribeToasts, toastSnapshot, () => emptyToasts);
}
